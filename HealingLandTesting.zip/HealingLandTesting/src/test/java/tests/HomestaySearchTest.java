package tests;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.HomestaySearchPage;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class HomestaySearchTest {
    private WebDriver driver;
    private HomestaySearchPage homestaySearchPage;
    private WebDriverWait wait;

    @BeforeEach
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        driver.get("http://localhost:8081/healingland/index.jsp"); // Đường dẫn tới trang index.jsp của bạn
        homestaySearchPage = new HomestaySearchPage(driver);
    }

    @Test
    public void testSearchWithBlankCheckOutDate() {
        // Select location
        homestaySearchPage.selectDistrict("Hải Châu");

        // Enter check-in date
        homestaySearchPage.enterCheckInDate("07-20-2024");

        // Leave check-out date blank
        homestaySearchPage.leaveCheckOutDateBlank();

        // Select number of guests
        homestaySearchPage.selectGuests("2");

        // Click search button
        homestaySearchPage.clickSearchButton();

        // Verify URL change after search
        String currentUrl = driver.getCurrentUrl();
        assertTrue(currentUrl.contains("searchServlet"), "URL should contain 'homestaySearch' after search");

        // Verify that the search results are displayed correctly
        WebElement searchResults = driver.findElement(By.id("search-results"));
        assertTrue(searchResults.isDisplayed(), "Search results should be displayed");

        // Verify the pagination
        WebElement pagination = driver.findElement(By.className("pagination"));
        assertTrue(pagination.isDisplayed(), "Pagination should be displayed");

        // Verify at least one result is displayed
        WebElement firstResult = searchResults.findElement(By.cssSelector(".result-item"));
        assertTrue(firstResult.isDisplayed(), "At least one search result should be displayed");
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
